export class DonePresent extends Phaser.Scene {
    constructor() {
        super('DonePresent');
    }

    create() {
        const WIDTH = this.game.scale.width;
        const HEIGHT = this.game.scale.height;

        const text =
            'Happy 2 years my love! I\'m so proud that we\'ve made it this far. I wouldn\'t mind going for more, though. ' +
            '20, 200, 2,000 years! FOREVER! My appreciation for you is unending. I met you at one of my lowest points in life. ' +
            'Something I\'ve noticed is that you never fail to cheer me up. You\'re so funny and just seeing you made my days better' +
            'You definitely motivate me because of that (look at this game... I hope u like it <3). I\'m too motivated, ' +
            'but you know how to calm me down. I\'m really sorry about moving our anniversary date, but you made doing that ' +
            'easy. You have no idea how much I appreciate your patience, not just that moment, but in other bad times. ' +
            'I know these bad, stressful times are happening more, but I will do the same for you. I will take care of you, ' +
            'I will listen to you. I will love you. I never want you to be afraid of sharing feelings. That\'s exactly what ' +
            'I\'m here for! I know we\'ve been busy, but being busy with you makes it a piece of cake. Mari, I love you so ' +
            'much. I\'m glad that I\'m yours and I\'m glad that we\'re growing together. Just sit back, relax, and enjoy our ' +
            'date today. You deserve it.';

        this.add.text(10, HEIGHT / 2, text, {
            fontFamily: 'Verdana',
            fontStyle: undefined,
            fontSize: '24px',
            stroke: '#000',
            strokeThickness: 0,
            wordWrap:{
                width: WIDTH / 1.5,
                useAdvancedWrap: true
            },
            align: 'center'
        }).setOrigin(0, 0.5);

        this.add.image(WIDTH, HEIGHT / 2, 'LEGEND').setOrigin(1, 0.5).setScale(0.4);
    }
};